#ifndef Rotor_Diseqc_h
#define Rotor_Diseqc_h

#include <vdr/dvbdevice.h>

#ifdef ROTORFRONTENDPATCH
#define Fd_Frontend cDvbDevice::Fd_Frontend(data.DvbCard) 
#else
#define Fd_Frontend data.fd_frontend
#endif

enum { Halt, LimitsOff, SetEastLimit, SetWestLimit, DriveEast, DriveStepsEast, DriveStepsWest, DriveWest, Store, Goto, Recalc, LimitsOn, Gotox};;
/*
class SatelliteList {
private:
  char name[100][50];
  int pos[100],code[100],num;
public:
  SatelliteList();
  void Add(const char* name, const char* description, int pos, int code);
  void SetPos(int Nr,int Pos) {pos[Nr]=Pos;};
  int GetNum(void) {return num-1;};
  int Code(int Nr) {return code[Nr];};
  int Pos(int Nr) {return pos[Nr];};
  int GetfromPos(int Pos);
  int GetfromSource(int Code);
  char* Name(int Nr) {return name[Nr];};
};
*/

void DiseqcCommand(int KNr, int p1=0, int p2=0);

void GotoX(int Source);

//extern SatelliteList List;

#endif
